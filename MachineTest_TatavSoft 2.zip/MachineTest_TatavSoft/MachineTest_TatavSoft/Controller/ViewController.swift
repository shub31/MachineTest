//
//  ViewController.swift
//  MachineTest_TatavSoft
//
//  Created by Apple on 16/07/21.
//

import UIKit


class ViewController: UIViewController {
    
    @IBOutlet weak var moviesCollectionView: UICollectionView!
    let viewModel = MoviesViewModel()
    var moviesArray = [Result]()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        moviesCollectionView.delegate = self
        moviesCollectionView.dataSource = self
        moviesCollectionView.reloadData()
       
        viewModel.fetchMoviesLIst()
        // Do any additional setup after loading the view.
        
        //Register UINib
        let nib = UINib(nibName: "MoviesListCollectionViewCell", bundle: nil)
        moviesCollectionView.register(nib, forCellWithReuseIdentifier: "MoviesListCollectionViewCell")
    }


}

extension ViewController: UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = moviesCollectionView.dequeueReusableCell(withReuseIdentifier: "MoviesListCollectionViewCell", for: indexPath) as! MoviesListCollectionViewCell
        let movie = moviesArray[indexPath.row]
        cell.titleLabel.text = movie.originalTitle
        cell.descriptionTextView.text = movie.overview
        print(cell.titleLabel.text)
        
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize.init(width: moviesCollectionView.frame.width, height: moviesCollectionView.frame.height)
    }
    
}
