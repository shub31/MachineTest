//
//  File.swift
//  MachineTest_TatavSoft
//
//  Created by Apple on 16/07/21.
//

import Foundation
struct Constant{
    
    static let moviesListUrl = "https://api.themoviedb.org/3/discover/movie?api_key=14bc774791d9d20b3a138bb6e26e2579"
}
