//
//  MoviesViewModel.swift
//  MachineTest_TatavSoft
//
//  Created by Apple on 16/07/21.
//

import Foundation
import Alamofire

class MoviesViewModel{
    
    var movieDataArray = [Result]()
    
    func fetchMoviesLIst(){
        AF.request(Constant.moviesListUrl).response { respone in
            if let data = respone.data{
            
            do {
                let moviesResponse = try JSONDecoder().decode(MovieList.self, from: data)
                self.movieDataArray = moviesResponse.results
                
                print(self.movieDataArray)
            } catch let err{
                print(err)
            }
        }
    
    }
    
}
}
